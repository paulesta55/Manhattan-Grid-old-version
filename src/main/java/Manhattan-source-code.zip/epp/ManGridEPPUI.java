package epp;

/**
 * Created by placisadmin on 28/02/2017.
 */
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.seamcat.model.Scenario;
import org.seamcat.model.factory.Factory;
import org.seamcat.model.functions.Function;
import org.seamcat.model.functions.Point2D;
import org.seamcat.model.plugin.Config;
import org.seamcat.model.plugin.antenna.ITU_R_F1336_4_rec_2_Input;
import org.seamcat.model.plugin.eventprocessing.PanelDefinition;
import org.seamcat.model.plugin.eventprocessing.Panels;
import org.seamcat.model.plugin.eventprocessing.PostProcessing;
import org.seamcat.model.plugin.eventprocessing.PostProcessingUI;
import org.seamcat.model.simulation.result.*;
import org.seamcat.model.types.AntennaGain;
import org.seamcat.model.types.InterferenceLink;
import org.seamcat.model.types.PropagationModel;
import org.seamcat.model.types.result.Results;
import org.seamcat.model.types.result.ScatterDiagramResultType;
import org.seamcat.model.types.result.VectorResult;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

import static org.seamcat.model.factory.Factory.build;
import static org.seamcat.model.factory.Factory.results;
import static org.seamcat.model.factory.Factory.when;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * Created by placisadmin on 03/01/2017.
 */
public class ManGridEPPUI extends JFrame implements PostProcessingUI  {
    private JSplitPane split;
    private JPanel plotPanel = new JPanel(new BorderLayout());
    private Panels panels;
    private List<Double> angles, values;

    private ManGridEPPUIinput inputPanel;

    private double[] vectorVLR_X;
    private double[] vectorVLR_Y;
    private double[] vectorVLT_X;
    private double[] vectorVLT_Y;
    private double[] vectorILR_X;
    private double[] vectorILR_Y;
    private double[] vectorILT_X;
    private double[] vectorILT_Y;
    protected double maxX,minX;
    protected double maxY,minY;
   /* private List<Double> vectorVLR_Y = new ArrayList<Double>();
    private List<Double> vectorVLT_X = new ArrayList<Double>();
    private List<Double> vectorVLT_Y = new ArrayList<Double>();

    private List<Double> vectorILR_X = new ArrayList<Double>();
    private List<Double> vectorILR_Y = new ArrayList<Double>();
    private List<Double> vectorILT_X = new ArrayList<Double>();
    private List<Double> vectorILT_Y = new ArrayList<Double>();*/

    private int nb_building=405;

    public String getTitle() {
        return "ManGridEPPUI";
    }

    public void buildUI(Scenario scenario, JPanel canvas, Panels panels) {
        this.panels = panels;
        split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.add(panels.get("Input").getPanel());
        split.add(plotPanel);
        canvas.setLayout( new BorderLayout() );
        canvas.add( split, BorderLayout.CENTER );
    }

    public PanelDefinition[] panelDefinitions() {
        return new PanelDefinition[]{
                new PanelDefinition("Input",ManGridEPPUIinput.class)
        };
    }

    public double getMaxTab(double[] tab)
    {
        double max = tab[0];

                for(int i=0; i<tab.length; i++)
        {
            if(tab[i]>max)
            max=tab[i];
        }
        return max;

    }

    public double getMinTab(double[] tab)
    {
        double min = tab[0];

        for(int i=0; i<tab.length; i++)
        {
            if(tab[i]<min)
                min=tab[i];
        }
        return min;

    }

    @PostProcessing(order = 2, name = "Plot pattern")
    public void preparePlot(Scenario scenario,Results results, ManGridEPP.Input input) {

        VectorResult posVLR_X = results.findVector(input.VLRX).getValue();
        VectorResult posVLR_Y = results.findVector(input.VLRY).getValue();
        VectorResult posVLT_X = results.findVector(input.VLTX).getValue();
        VectorResult posVLT_Y = results.findVector(input.VLTY).getValue();
        VectorResult posILR_X = results.findVector(input.ILRX).getValue();
        VectorResult posILR_Y = results.findVector(input.ILRY).getValue();
        VectorResult posILT_X = results.findVector(input.ILTX).getValue();
        VectorResult posILT_Y = results.findVector(input.ILRY).getValue();

        /*VectorResult posVLR_Y = results.findVector(ManGridEPP.Input.VLRY.name()).getValue();
        VectorResult posVLR_Y = results.findVector(ManGridEPP.Input.VLRY.name()).getValue();
        VectorResult posVLT_X = results.findVector(ManGridEPP.Input.VLTX.name()).getValue();
        VectorResult posVLT_Y = results.findVector(ManGridEPP.Input.VLTY.name()).getValue();
        VectorResult posILR_X = results.findVector(ManGridEPP.Input.ILRX.name()).getValue();
        VectorResult posILR_Y = results.findVector(ManGridEPP.Input.ILRY.name()).getValue();
        VectorResult posILT_X = results.findVector(ManGridEPP.Input.ILTX.name()).getValue();
        VectorResult posILT_Y = results.findVector(ManGridEPP.Input.ILTY.name()).getValue();*/
        vectorVLR_X = posVLR_X.asArray();
        vectorVLR_Y = posVLR_Y.asArray();
        vectorVLT_X = posVLT_X.asArray();
        vectorVLT_Y = posVLT_Y.asArray();
        vectorILR_X= posILR_X.asArray();
        vectorILR_Y = posILR_Y.asArray();
        vectorILT_X= posILT_X.asArray();
        vectorILT_Y= posILT_Y.asArray();

       // for(int i=0;i<vectorVLR_X.length;i++)

        //{
           // System.out.println("vlrx=" + vectorVLR_X[i] + "size=" + posVLR_X.size());//+" vlry="+posVLR_Y.get(i)+" ilrx="+posILR_X.get(i)+" ilry="+posILR_Y.get(i));
            //System.out.println("vltx="+posVLT_X.get(i)+" vlty="+posVLT_Y.get(i)+" iltx="+posILT_X.get(i)+" ilty="+posILT_Y.get(i));
       // }
        double maxVLRX=getMaxTab(vectorVLR_X);
        double maxVLTX=getMaxTab(vectorVLT_X);
        double maxILTX=getMaxTab(vectorILT_X);
        double maxILRX=getMaxTab(vectorILR_X);
        double[] tabX={maxILRX,maxILTX,maxVLRX,maxVLTX};
        maxX= getMaxTab(tabX);

        double maxVLRY=getMaxTab(vectorVLR_Y);
        double maxVLTY=getMaxTab(vectorVLT_Y);
        double maxILTY=getMaxTab(vectorILT_Y);
        double maxILRY=getMaxTab(vectorILR_Y);
        double[] tabY={maxILRY,maxILTY,maxVLRY,maxVLTY};
        maxY= getMaxTab(tabY);

        double minVLRX=getMinTab(vectorVLR_X);
        double minVLTX=getMinTab(vectorVLT_X);
        double minILTX=getMinTab(vectorILT_X);
        double minILRX=getMinTab(vectorILR_X);
        double[] tabminX={minILRX,minILTX,minVLRX,minVLTX};
        minX= getMinTab(tabminX);

        double minVLRY=getMaxTab(vectorVLR_Y);
        double minVLTY=getMaxTab(vectorVLT_Y);
        double minILTY=getMaxTab(vectorILT_Y);
        double minILRY=getMaxTab(vectorILR_Y);
        double[] tabminY={minILRY,minILTY,minVLRY,minVLTY};
        minY= getMinTab(tabY);

        System.out.println("maxX"+maxX+"maxY"+maxY);


/*
            vectorVLR_Y.add(posVLR_Y.asArray());
            vectorILR_X.add(posILR_X.get(i));
            vectorILR_Y.add(posILR_Y.get(i));
            vectorILT_X.add(posILT_X.get(i));
            vectorILT_Y.add(posILT_Y.get(i));
            vectorVLT_X.add(posVLT_X.get(i));
            vectorVLT_Y.add(posVLT_Y.get(i));*/


        inputPanel = (ManGridEPPUIinput) panels.get("Input").getModel();

        nb_building=inputPanel.nb_building();


        dothis(scenario);
    }

    private void dothis(Scenario scenario) {
        generatePlot();
    }

    private void generatePlot() {

        plotPanel.removeAll();
        XYSeriesCollection dataset = new XYSeriesCollection();
        String plane = "horizontal";
        XYSeries pattern = new XYSeries(plane);


       /*Interface g= new Interface(vectorVLR_X,vectorVLR_Y,vectorVLT_X,vectorVLT_Y,vectorILR_X,vectorILR_Y,vectorILT_X,vectorILT_Y, nb_building);
        for (int i = 0; i < angles.size(); i++) {
            pattern.add(angles.get(i), values.get(i));
        }
        setTitle("Manhattan Grid Generation Plugin");
        int maxXe= (int) maxX;
        int maxYe= (int) maxY;
        setSize(800,800);

        Grid grid = new Grid(vectorVLR_X, vectorVLR_Y, vectorVLT_X, vectorVLT_Y,vectorILR_X,vectorILR_Y,vectorILT_X,vectorILT_Y,nb_building);
        ManhattanChart Mgrid = new ManhattanChart();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

       getContentPane().add(grid, BorderLayout.CENTER);

        setVisible(true);*/


        /*dataset.addSeries(pattern);
       final JFreeChart dRSSchart = ChartFactory.createXYLineChart("bla", "off axis [degrees]", "gain [dBi]", dataset, PlotOrientation.VERTICAL, true, true, false);
        dRSSchart.fireChartChanged();
        XYPlot plot = (XYPlot) dRSSchart.getPlot(); // REMARK: color changed for better visibility
        plot.getRenderer().setSeriesPaint(0, Color.BLUE);
        final ChartPanel cp = new ChartPanel(dRSSchart);
        cp.repaint();
        plotPanel.add(cp, BorderLayout.CENTER);
        plotPanel.revalidate();
        plotPanel.repaint();
        split.repaint();*/
    }
}
