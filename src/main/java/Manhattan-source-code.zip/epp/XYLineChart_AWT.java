package epp;

/**
 * Created by placisadmin on 28/02/2017.
 */
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;


public class XYLineChart_AWT extends ApplicationFrame {

    public XYLineChart_AWT(String applicationTitle, String chartTitle) {

        super(applicationTitle);

        Canvas test=new Canvas();

        NumberAxis xAxis=new NumberAxis("Category");
        NumberAxis yAxis=new NumberAxis("Score");
        XYItemRenderer itemrenderer = new XYLineAndShapeRenderer(true,false);
        final XYPlotWithZoomableBackgroundImage myplot = new XYPlotWithZoomableBackgroundImage(createDataset(),xAxis,yAxis,itemrenderer,true);


        JFreeChart xylineChart = new JFreeChart(chartTitle,JFreeChart.DEFAULT_TITLE_FONT,myplot,true);

         /*
         ChartFactory.createXYLineChart(
                chartTitle,
                "Category",
                "Score",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false
        );
        */




        ChartPanel chartPanel = new ChartPanel(xylineChart);


        /*


        chartPanel.addChartMouseListener(new ChartMouseListener() {

            @Override
            public void chartMouseClicked(ChartMouseEvent cme) {
                report(cme);
                System.out.println("coucou");

            }

            @Override
            public void chartMouseMoved(ChartMouseEvent cme) {
                //report(cme);
            }

            private void report(ChartMouseEvent cme) {
                ChartEntity ce = cme.getEntity();
                if (ce instanceof XYItemEntity) {
                    XYItemEntity e = (XYItemEntity) ce;
                    XYDataset d = e.getDataset();
                    int s = e.getSeriesIndex();
                    int i = e.getItem();
                    System.out.println("X:" + d.getX(s, i) + ", Y:" + d.getY(s, i));
                }
            }
        });
*/


        chartPanel.setPreferredSize(new java.awt.Dimension(400,400));


        // Définition du fond du graphe
        File f=new File("");

        System.out.println(f.getAbsolutePath());

        ImageIcon icon = new ImageIcon("soleil.png");
        //ImageIcon icon2 = new ImageIcon(test.takeSnapShot());
        myplot.setBackgroundImage(icon.getImage());
        //myplot.setBackgroundImage(test.takeSnapShot());


        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

        renderer.setSeriesPaint(0, Color.RED);
        renderer.setSeriesPaint(1, Color.GREEN);
        renderer.setSeriesPaint(2, Color.YELLOW);
        renderer.setSeriesStroke(0, new BasicStroke(4.0f));
        renderer.setSeriesStroke(1, new BasicStroke(3.0f));
        renderer.setSeriesStroke(2, new BasicStroke(2.0f));



        myplot.setRenderer(renderer);
        setContentPane(chartPanel);
    }
    /*
    private JButton createZoom(){
        final JButton auto = new JButton(new AbstractAction("Auto Zoom"){

            @Override
        public void actionPerformed(ActionEvent e){
                chartPanel.restoreAutoBounds();
            }
        });
    }
    */

    private XYDataset createDataset() {


        final XYSeries firefox = new XYSeries("Firefox");
        firefox.add(1.0, 1.0);
        firefox.add(2.0, 4.0);
        firefox.add(3.0, 3.0);
        final XYSeries chrome = new XYSeries("Chrome");
        chrome.add(1.0, 4.0);
        chrome.add(2.0, 5.0);
        chrome.add(3.0, 6.0);
        final XYSeries iexplorer = new XYSeries("InternetExplorer");
        iexplorer.add(3.0, 4.0);
        iexplorer.add(4.0, 5.0);
        iexplorer.add(5.0, 4.0);
        final XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(firefox);
        dataset.addSeries(chrome);
        dataset.addSeries(iexplorer);
        return dataset;
    }

/*

    public static void main(String[] args) {

        File f=new File("");

        System.out.println(f.getAbsolutePath());
        XYLineChart_AWT chart = new XYLineChart_AWT(
                "Browser Usage Statistics",
                "Which Browser are you using?"
        );
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
*/

}

