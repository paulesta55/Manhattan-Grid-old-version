package epp;

/**
 * Created by placisadmin on 28/02/2017.
 */
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


import org.jfree.ui.RefineryUtilities;
//import org.seamcat.model.plugin.eventprocessing.ResultCollector;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Grid extends JPanel
{
    private static final long serialVersionUID = 1L;
    private JLabel Grid = new JLabel("Manhattan Grid");
    private JLabel Legend = new JLabel("Number of floors");
    //private Manhattan_Image image;
    private MMap map=new MMap();

    private int nbLines = 200;
    private int nbColumns = 200;
    private int MaxLines=500;
    private int MaxColumns=500;
    private int BuildingSize = 10;
    private int AvailableHeightGap;
    private int AvailableWidthGap;
    private int AvailableHeight;
    private int AvailableWidth;
    private int BuildingHeightMeanSize = 3;
    private int BuildingWidthMeanSize = 2;
    private int MaxFloor = 10;
    private double BuildingHeightStdDevSize = 1;
    private double BuildingWidthStdDevSize = 1.5;
    private int Height = 0;
    private int Width = 0;
    private int Floor = 0;
    private int m = 0;
    private int n = 0;
    private int[][] Matrix = new int[nbLines][nbColumns];
    private int Blue=0;
    private int Red=0;
    private int Green=0;
    private GridBagLayout GridBag = new GridBagLayout();
    private ArrayList<Building> Cellule = new ArrayList<Building>();
    protected double a,b,c,d;

    private XYDataset Event_dataset;
    //private JLabel Size = new JLabel("T");


    /*public Grid(){
        super();
        Create();
        Generate();
    }*/

    public Grid(double[] vectorVLR_X, double[] vectorVLR_Y,double[] vectorVLT_X, double[] vectorVLT_Y,double[] vectorILR_X,double[] vectorILR_Y,  double[] vectorILT_X, double[] vectorILT_Y,  int nb_building)
    {
        super();
        Create();
        Event_dataset =  createDataset(vectorVLR_X, vectorVLR_Y, vectorVLT_X, vectorVLT_Y,vectorILR_X,vectorILR_Y,vectorILT_X,vectorILT_Y);
        Generate(nb_building);
    }

    public void Create()
    {

        AvailableHeightGap = BuildingSize-1;
        AvailableWidthGap = BuildingSize-1;
        AvailableHeight = nbLines;
        AvailableWidth = nbColumns;

        Matrix = new int[nbLines][nbColumns];

        for(int i=1; i<=nbLines; i++){
            for(int j=1; j<=nbColumns; j++){

                if((i%BuildingSize)==0||(j%BuildingSize)==0){
                    Matrix[i-1][j-1]=0;
                }
                else{
                    Matrix[i-1][j-1]=1;
                }
            }
        }

        for(int i=0; i<nbLines; i = i + BuildingSize){
            n=i;

            while(AvailableHeightGap!=0){
                Height = (int)(BuildingHeightMeanSize+BuildingHeightStdDevSize*Math.random());
                if(AvailableHeightGap>=AvailableHeight){
                    AvailableHeightGap=AvailableHeight;
                }
                if(Height>=AvailableHeightGap){
                    Height=AvailableHeightGap;
                }
                AvailableHeightGap=AvailableHeightGap-Height;
                AvailableHeight=AvailableHeight-Height;

                for(int j=0; j<nbColumns; j = j + BuildingSize){
                    m=j;
                    while(AvailableWidthGap!=0){
                        Width=(int)(BuildingWidthMeanSize+BuildingWidthStdDevSize*Math.random());
                        Floor=(int)(2+(MaxFloor-2)*Math.random());
                        if(AvailableWidthGap>=AvailableWidth){
                            AvailableWidthGap=AvailableWidth;
                        }
                        if(Width>=AvailableWidthGap){
                            Width=AvailableWidthGap;
                        }
                        AvailableWidthGap=AvailableWidthGap-Width;
                        AvailableWidth=AvailableWidth-Width;
                        for(int k=n;k<=n+Height-1;k++)
                        {
                            for(int l=m;l<=m+Width-1;l++)
                                Matrix[k][l]=Floor;
                        }

                        m=m+Width;
                    }
                    AvailableWidthGap=BuildingSize-1;
                    AvailableWidth=AvailableWidth-1;

                }
                AvailableWidth=nbColumns;
                n=n+Height;
            }
            AvailableHeightGap=BuildingSize-1;
            AvailableHeight=AvailableHeight-1;
        }

    }

    public void Generate(int nb_building)
    {

        removeAll();

        setLayout(GridBag);
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = nbColumns;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);

        add(Grid,gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(Legend,gbc);

        gbc.gridwidth = 1;
        gbc.gridheight = 100;
        gbc.ipady = 0;
        gbc.ipadx = 0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = 1;



        /*repaint();
        JScrollPane Scroll = new JScrollPane(map);
        Scroll.setMaximumSize(new Dimension(MaxLines,MaxColumns));
        Scroll.setMinimumSize(new Dimension(MaxLines, MaxColumns));
        Scroll.setPreferredSize(new Dimension(MaxLines, MaxColumns));
        add(Scroll, gbc);
        repaint();
        map.setVisible(true);

        */

        //DEBUT TEST
        NumberAxis xAxis=new NumberAxis("X Distance (km)");
        NumberAxis yAxis=new NumberAxis("Y Distance (km)");
        XYItemRenderer itemrenderer = new XYLineAndShapeRenderer(true,false);

        //Very important line!!!! where we really creat the grid
        final XYPlotWithZoomableBackgroundImage myplot = new XYPlotWithZoomableBackgroundImage(Event_dataset,xAxis,yAxis,itemrenderer,true);

        JFreeChart chart = new JFreeChart("Manhattan Grid for SEAMCAT By Ning",JFreeChart.DEFAULT_TITLE_FONT,myplot,true);

        mynewxyplot chartPanel = new mynewxyplot(chart, Matrix, nbLines, nbColumns, MaxFloor,nb_building);


        XYLineChart_AWT Achart = new XYLineChart_AWT("test","test");


        Achart.pack();
        RefineryUtilities.centerFrameOnScreen(Achart);
        add(chartPanel,gbc);

        repaint();
        //FIN TEST

        gbc.gridheight = 1;

        for(int i=0; i<100; i++){
            gbc.gridy = i+1;
            gbc.gridx = 1;
            gbc.insets = new Insets(0, 40, 0, 0);
            if(i<=100/2){
                Red=255-i*255*2/100;
                Green=i*255*2/100;
                Blue=0;
            }
            else{
                Green=255*2-i*255*2/100;
                Blue=i*255/100;
                Red=0;
            }
            JPanel panel = new JPanel();
            panel.setMaximumSize(new Dimension(50,50/(MaxFloor+1)));
            panel.setMinimumSize(new Dimension(50,50/(MaxFloor+1)));
            panel.setPreferredSize(new Dimension(50,50/(MaxFloor+1)));
            panel.setBackground(new Color(Red,Green,Blue));
            add(panel, gbc);
        }
        gbc.insets = new Insets(0, 10, 0, 0);
        gbc.gridheight = 2;

        gbc.gridheight = 1;
        for(int i=0; i<=MaxFloor; i++){
            gbc.gridx = 2;
            gbc.gridy = i*100/MaxFloor+1;
            add(new JLabel(String.valueOf(MaxFloor-i)), gbc);
        }

    }

    public void setnbLines(int nbLines){
        //if(nbLines>MaxLines) this.nbLines=MaxLines;
        //else
        this.nbLines=nbLines;
    }
    public void setnbColumns(int nbColumns){
        //if(nbColumns>MaxColumns) this.nbColumns=MaxColumns;
        //else
        this.nbColumns=nbColumns;
    }
    public void setBuildingSize(int BuildingSize){
        this.BuildingSize=BuildingSize;
    }
    public void setBuildingHeightMeanSize(int BuildingHeightMeanSize){
        this.BuildingHeightMeanSize=BuildingHeightMeanSize;
    }
    public void setBuildingWidthMeanSize(int BuildingWidthMeanSize){
        this.BuildingWidthMeanSize=BuildingWidthMeanSize;
    }
    public void setBuildingHeightStdDevSize(int BuildingHeightStdDevSize){
        this.BuildingHeightStdDevSize=BuildingHeightStdDevSize;
    }
    public void setBuildingWidthStdDevSize(int BuildingWidthStdDevSize){
        this.BuildingWidthStdDevSize=BuildingWidthStdDevSize;
    }
    public void setMaxFloor(int MaxFloor){
        this.MaxFloor=MaxFloor;
    }
    public void clearCellule(){
        Cellule.clear();
    }
    public int CelluleSize(){
        return Cellule.size();
    }



    private XYDataset createDataset(double[] vectorVLR_X, double[] vectorVLR_Y,double[] vectorVLT_X, double[] vectorVLT_Y,double[] vectorILR_X,double[] vectorILR_Y,  double[] vectorILT_X, double[] vectorILT_Y)
    {

        int length_VLRX = vectorVLR_X.length;
        System.out.println("nb of vectors: "+length_VLRX);

        final XYSeries VLR = new XYSeries("VLR");
        final XYSeries ILR = new XYSeries("ILR");
        final XYSeries VLT = new XYSeries("VLT");
        final XYSeries ILT = new XYSeries("ILT");

        int EventConuter;
        for(EventConuter=0;EventConuter<length_VLRX;EventConuter++)
        {
            VLR.add(vectorVLR_X[EventConuter],vectorVLR_Y[EventConuter]);
            VLT.add(vectorVLT_X[EventConuter],vectorVLT_Y[EventConuter]);
            ILR.add(vectorILR_X[EventConuter],vectorILR_Y[EventConuter]);
            ILT.add(vectorILT_X[EventConuter],vectorILT_Y[EventConuter]);

            /*
            ILR.add(vectorILR_X.get(EventConuter), vectorILR_Y.get(EventConuter));
            VLT.add(vectorVLT_X.get(EventConuter), vectorVLT_Y.get(EventConuter));
            ILT.add(vectorILT_X.get(EventConuter), vectorILT_Y.get(EventConuter)); */
        }

        final XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(ILT);
        dataset.addSeries(VLT);
        dataset.addSeries(ILR);
        dataset.addSeries(VLR);

        return dataset;

    };


    public void addTransmitter(Point p){
        map.addTransmitter(p);
    }
    public void addReceiver(Point p){
        map.addReceiver(p);
    }
    public int getNbColumns(){
        return nbColumns;
    }
    public int getNbLines(){
        return nbLines;
    }
    public Point getGridBagLocation(int x,int y){
        return GridBag.location(x, y);
    }
    public int getFloorAt(int x,int y){
        return Matrix[x][y];
    }
    public int getMatrixValueAt(int i, int j){
        return Matrix[i][j];
    }
    public int getMapCellWidth(){
        return map.getCellWidth();
    }
    public int getMapCellHeight(){
        return map.getCellHeight();
    }


}
