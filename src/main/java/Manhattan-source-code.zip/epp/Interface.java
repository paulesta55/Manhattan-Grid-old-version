package epp;

/**
 * Created by placisadmin on 28/02/2017.
 */
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;


public class Interface extends JFrame {
    protected double a,b;
    private Grid grid;
    private ManhattanChart Mgrid;

    /*public Interface()
    {
        setTitle("Manhattan strip");
        setSize(800,800);
        grid = new Grid();
        Mgrid = new ManhattanChart();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        getContentPane().add(grid, BorderLayout.CENTER);

        setVisible(true);
    }*/

    public Interface(double[] vectorVLR_X, double[] vectorVLR_Y,double[] vectorVLT_X, double[] vectorVLT_Y,double[] vectorILR_X, double[] vectorILR_Y,  double[] vectorILT_X,  double[] vectorILT_Y, int nb_building)
    {
        setTitle("Manhattan Grid Generation Plugin");
        setSize(800,800);
        grid = new Grid(vectorVLR_X, vectorVLR_Y, vectorVLT_X, vectorVLT_Y,vectorILR_X,vectorILR_Y,vectorILT_X,vectorILT_Y,nb_building);
        Mgrid = new ManhattanChart();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        getContentPane().add(grid, BorderLayout.CENTER);

        setVisible(true);
    }


}