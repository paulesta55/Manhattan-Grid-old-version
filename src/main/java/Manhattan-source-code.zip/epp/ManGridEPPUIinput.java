package epp;

import org.seamcat.model.plugin.Config;

/**
 * Created by placisadmin on 28/02/2017.
 */
public interface ManGridEPPUIinput {

    @Config(order = 1, name = "Nombers of blocks ") int nb_building();
    int nb_building = 305;
}
