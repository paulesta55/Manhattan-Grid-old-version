package epp;

/**
 * Created by placisadmin on 28/02/2017.
 */
import org.seamcat.model.Scenario;

import org.seamcat.model.factory.Factory;
import org.seamcat.model.plugin.Config;
import org.seamcat.model.plugin.eventprocessing.PostProcessingUITab;
import org.seamcat.model.plugin.system.ConsistencyCheckContext;
import org.seamcat.model.simulation.consistency.Validator;
import org.seamcat.model.plugin.eventprocessing.EventProcessingPlugin;

import org.seamcat.model.simulation.result.*;

import org.seamcat.model.types.Description;
import org.seamcat.model.types.InterferenceLink;
import org.seamcat.model.types.result.DescriptionImpl;
//import org.seamcat.model.types.result.ResultTypes;
import java.util.List;
import org.seamcat.model.simulation.result.Collector;
import org.seamcat.model.simulation.result.InterferenceLinkResults;
//import org.seamcat.model.simulation.result.InterferenceLinkResult;


@PostProcessingUITab(ManGridEPPUI.class)
public class ManGridEPP implements EventProcessingPlugin<ManGridEPP.Input>
{
    protected  int nb_building=405;

    public void evaluate(Scenario scenario, EventResult eventResult, Input input, Collector resultCollector )
    {
        for (InterferenceLink link : scenario.getInterferenceLinks()) {
            /*InterferenceLinkResults linkResult = eventResult.getInterferenceLinkResult(link);*/
           // InterferenceLinkResults linkResult = (InterferenceLinkResults) eventResult.getInterferenceLinkResult(link);

            LinkResult victimResult = eventResult.getInterferenceLinkResult(link).get(0).getVictimSystemLink();
            /*resultCollector.add(Input.VLRX.name(),Input.VLRX.unit(),victimResult.rxAntenna().getPosition().getX());
            resultCollector.add(Input.VLRY.name(),Input.VLRY.unit(),victimResult.rxAntenna().getPosition().getY());
            resultCollector.add(Input.VLTX.name(),Input.VLTX.unit(),victimResult.txAntenna().getPosition().getX());
            resultCollector.add(Input.VLTY.name(),Input.VLTY.unit(),victimResult.txAntenna().getPosition().getY());*/
            resultCollector.add(Input.VLRX,victimResult.rxAntenna().getPosition().getX());
            resultCollector.add(Input.VLRY,victimResult.rxAntenna().getPosition().getY());
            resultCollector.add(Input.VLTX,victimResult.txAntenna().getPosition().getX());
            resultCollector.add(Input.VLTY,victimResult.txAntenna().getPosition().getY());


           /* resultCollector.addVectorGroupPoint(groupVLRY,"vlry", unit,victimResult.rxAntenna().getPosition().getY());
            resultCollector.addVectorGroupPoint(groupVLTX,"vltx", unit,victimResult.txAntenna().getPosition().getX());
            resultCollector.addVectorGroupPoint(groupVLTY,"vlty", unit,victimResult.txAntenna().getPosition().getY()); */
            System.out.println("x="+victimResult.rxAntenna().getPosition().getX());
            System.out.println("y="+victimResult.rxAntenna().getPosition().getY());

           // List<? extends InterferenceLinkResult> subLinkResults = linkResult.getInterferenceLinkResults();
            for (int i = 0; i < eventResult.getInterferenceLinkResult(link).size(); i++) {
                LinkResult lr= eventResult.getInterferenceLinkResult(link).get(i).getInterferingSystemLink();
                //LinkResult lr = subLinkResults.get(i).getInterferingSystemLink();
                String iName = link.getInterferer().toString();
                resultCollector.add(Input.ILRX,lr.rxAntenna().getPosition().getX());
                resultCollector.add(Input.ILRY,lr.rxAntenna().getPosition().getY());
                resultCollector.add(Input.ILTX,lr.txAntenna().getPosition().getX());
                resultCollector.add(Input.ILTY,lr.txAntenna().getPosition().getY());
              /*  resultCollector.addVectorGroupPoint(groupILRX,"ilrx", unit, lr.rxAntenna().getPosition().getX());
                resultCollector.addVectorGroupPoint(groupILRY,"ilry", unit, lr.rxAntenna().getPosition().getY());
                resultCollector.addVectorGroupPoint(groupILTX,"iltx", unit, lr.txAntenna().getPosition().getX());
                resultCollector.addVectorGroupPoint(groupILTY,"ilty", unit, lr.txAntenna().getPosition().getY());


                resultCollector.addVectorPoint(Input.ILRY.name(),Input.ILRY.unit(),lr.rxAntenna().getPosition().getY());
                resultCollector.addVectorPoint(Input.ILTX.name(),Input.ILTX.unit(),lr.txAntenna().getPosition().getX());
                resultCollector.addVectorPoint(Input.ILTY.name(),Input.ILTY.unit(),lr.txAntenna().getPosition().getY());*/
            }
        }

    }




    public void consistencyCheck(Scenario scenario, List<Object> list, Input input, Validator<Input> validator)
    {

    }

    public Description description()
    {
        return new DescriptionImpl("Manhattan Grid","This EPP creates a random manhattan grid.");
    }

    @Override
    public void consistencyCheck(ConsistencyCheckContext consistencyCheckContext, Input input, Validator<Input> validator) {

    }

    public interface Input
    {

        ValueDef VLRX = Factory.results().value("VLR position X","km");
        ValueDef VLRY = Factory.results().value("VLR position Y","km");
        ValueDef VLTX = Factory.results().value("VLT position X","km");
        ValueDef VLTY = Factory.results().value("VLT position Y","km");
        ValueDef ILRX = Factory.results().value("ILR position X","km");
        ValueDef ILRY = Factory.results().value("ILR position Y","km");
        ValueDef ILTX = Factory.results().value("ILT position X","km");
        ValueDef ILTY = Factory.results().value("ILT position Y","km");
/*
        @Config(order = 1, name = "Nombers of blocks: 9 ") boolean nb_building9();
        @Config(order = 2, name = "Nombers of blocks: 16 ") boolean nb_building16();
        @Config(order = 3, name = "Nombers of blocks: 25 ") boolean nb_building25();
        @Config(order = 4, name = "Nombers of blocks: 36 ") boolean nb_building36();
        @Config(order = 5, name = "Nombers of blocks: 49 ") boolean nb_building49();
        @Config(order = 6, name = "Nombers of blocks: 64 ") boolean nb_building64();
        @Config(order = 7, name = "Nombers of blocks: 81 ") boolean nb_building81();
        @Config(order = 8, name = "Nombers of blocks: 100 ") boolean nb_building100();
        @Config(order = 9, name = "Nombers of blocks: 400 ") boolean nb_building400();
*/
    }

}
